
#!/bin/bash

# ==========================================
# MT7922 Firmware Header Generator
# ==========================================

cd "$(dirname "$0")" || exit 1

echo "=========================================="
echo " MT7922 Firmware Header Generator"
echo "=========================================="
echo "Working directory: $(pwd)"
echo

if ! command -v xxd >/dev/null 2>&1; then
    echo "[ERROR] xxd not found!"
    read -r -p "Press Enter to exit..."
    exit 1
fi

generate_header() {
    local bin_file="$1"
    local header_file="$2"
    local array_name="$3"

    echo "[INFO] Processing: ${bin_file}"

    if [ ! -f "$bin_file" ]; then
        echo "[ERROR] File not found: $bin_file"
        return 1
    fi

    local file_size
    local sha256

    file_size=$(wc -c < "$bin_file" | tr -d '[:space:]')
    sha256=$(shasum -a 256 "$bin_file" | awk '{print $1}')

    # 先生成临时文件，成功后再覆盖目标文件
    local temp_file="${header_file}.tmp"

    {
        echo "// Source: ${bin_file}"
        echo "// Size: ${file_size} bytes"
        echo "// SHA256: ${sha256}"
        echo

        echo "static const unsigned char ${array_name}[] = {"

        # xxd 直接读取文件
        xxd -i "$bin_file" |
            sed -n '/{/,/};/p' |
            sed '1s/.*{//; $s/};.*//'

        echo "};"
        echo

        echo "static constexpr size_t ${array_name}Size ="
        echo "    sizeof(${array_name});"
        echo

        echo "static_assert(sizeof(${array_name}) == ${file_size},"
        echo '              "Firmware size mismatch");'

    } > "$temp_file"

    if [ $? -ne 0 ] || [ ! -s "$temp_file" ]; then
        echo "[ERROR] Generation failed: $header_file"
        rm -f "$temp_file"
        return 1
    fi

    # 验证生成的数组确实有内容
    if ! grep -q '0x[0-9a-fA-F]' "$temp_file"; then
        echo "[ERROR] Generated array is empty!"
        rm -f "$temp_file"
        return 1
    fi

    # 成功后覆盖旧文件
    mv -f "$temp_file" "$header_file"

    echo "[OK] Generated: $header_file"
    echo "     Size: ${file_size} bytes"
    echo "     SHA256: ${sha256}"
    echo
}

# ==========================================
# Firmware configuration
# ==========================================

generate_header \
    "WIFI_MT7922_patch_mcu_1_1_hdr.bin" \
    "wifipatchmcu.h" \
    "wifiPatchData" || exit 1

generate_header \
    "WIFI_RAM_CODE_MT7922_1.bin" \
    "wifiramcode.h" \
    "wifiRamCodeData" || exit 1

echo "=========================================="
echo " All firmware headers generated!"
echo "=========================================="

read -r -p "Press Enter to exit..."
